//file written by Dr. Dmitri Loguinov
//Kraig Orcutt, CSCE 463-500 Spring 2018
#pragma once

#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <mmsystem.h>
#include <queue>
#include <map>
#include <set>
#include <string>
#include <iostream>
#include <tchar.h>
#include <fstream>
#include <time.h>
#include "targetver.h"
#include <unordered_set>


using namespace std;