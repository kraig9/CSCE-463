//file written by Dr. Dmitri Loguinov
//Kraig Orcutt, CSCE 463-500 Spring 2018
#pragma once

#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <mmsystem.h>
#include <queue>
#include <map>
#include <set>
#include <string>
#include <iostream>
#include <tchar.h>
#include <fstream>
#include <time.h>
#include "targetver.h"
#include <unordered_set>
#include "WinBase.h"
#include <ostream>

#define MAX_HOST_LEN		256
#define MAX_URL_LEN			2048
#define MAX_REQUEST_LEN		2048
#define MAX_PATH_LEN		1792


using namespace std;